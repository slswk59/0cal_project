package shopping.dto;

public class Or_detailDTO {
	private int or_detail_key;
	private int or_pr_count;
	private int or_pr_price;
	
	 public Or_detailDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getOr_detail_key() {
		return or_detail_key;
	}

	public void setOr_detail_key(int or_detail_key) {
		this.or_detail_key = or_detail_key;
	}

	public int getOr_pr_count() {
		return or_pr_count;
	}

	public void setOr_pr_count(int or_pr_count) {
		this.or_pr_count = or_pr_count;
	}

	public int getOr_pr_price() {
		return or_pr_price;
	}

	public void setOr_pr_price(int or_pr_price) {
		this.or_pr_price = or_pr_price;
	}
	
	 

}
