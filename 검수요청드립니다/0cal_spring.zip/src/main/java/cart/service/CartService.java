package cart.service;

public interface CartService {

	static void addCart(int userId, int productId) {
		// TODO Auto-generated method stub
		
	}

}
