package cart.service;

public class CartServiceImp implements CartService {

	@Override
	public void addCart(int userId, int productId) {
		// TODO Auto-generated method stub
		
	}

}
